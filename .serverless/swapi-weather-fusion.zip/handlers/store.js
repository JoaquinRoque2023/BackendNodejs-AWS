import { putCustom } from "../lib/dynamo.js";
import { v4 as uuidv4 } from "uuid";
/**
 * @openapi
 * /almacenar:
 *   post:
 *     summary: Almacenar datos personalizados
 *     description: Guarda datos personalizados del usuario en la base de datos DynamoDB.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             description: Datos a almacenar, se incluirán como parte del item junto con campos automáticos.
 *             example:
 *               category: "favorites"
 *               data: { key1: "value1", key2: "value2" }
 *     responses:
 *       201:
 *         description: Datos almacenados exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "stored"
 *                 item:
 *                   type: object
 *                   description: Item almacenado en la base de datos con claves generadas
 *                   properties:
 *                     pk:
 *                       type: string
 *                       example: "CUSTOM#d0f2f8d3-45a1-4b34-8a60-efae2f2e78a3"
 *                     sk:
 *                       type: string
 *                       format: date-time
 *                       example: "ITEM#2025-08-10T22:30:00.000Z"
 *                     id:
 *                       type: string
 *                       format: uuid
 *                       example: "d0f2f8d3-45a1-4b34-8a60-efae2f2e78a3"
 *                     createdAt:
 *                       type: string
 *                       format: date-time
 *                       example: "2025-08-10T22:30:00.000Z"
 *                     category:
 *                       type: string
 *                       example: "favorites"
 *                     data:
 *                       type: object
 *                       example:
 *                         key1: "value1"
 *                         key2: "value2"
 *       400:
 *         description: Body requerido
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "body required"
 *       500:
 *         description: Error interno del servidor
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Error message"
 */

export const handler = async (event) => {
  try {
    if (!event.body) {
      return { statusCode: 400, body: JSON.stringify({ message: "body required" }) };
    }
    
    const body = JSON.parse(event.body);
    const id = uuidv4();
    
    const item = {
      pk: `CUSTOM#${id}`, // Clave primaria
      sk: `ITEM#${new Date().toISOString()}`, // Clave de ordenamiento
      id: id,
      createdAt: new Date().toISOString(),
      ...body
    };
    
    await putCustom(item);
    return { statusCode: 201, body: JSON.stringify({ message: "stored", item }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ message: err.message }) };
  }
};
